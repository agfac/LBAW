<?php /* Smarty version Smarty-3.1.15, created on 2017-05-29 21:31:49
         compiled from "/Applications/MAMP/htdocs/LBAW/proto/templates/admin/common/footer.tpl" */ ?>
<?php /*%%SmartyHeaderCode:310310045592c8535d1b646-94226991%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '4c7197b94dfc128ab3d1ca5f83c9898a79c0db22' => 
    array (
      0 => '/Applications/MAMP/htdocs/LBAW/proto/templates/admin/common/footer.tpl',
      1 => 1495438243,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '310310045592c8535d1b646-94226991',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'BASE_URL' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.15',
  'unifunc' => 'content_592c8535d422a8_50843265',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_592c8535d422a8_50843265')) {function content_592c8535d422a8_50843265($_smarty_tpl) {?>
        <!-- footer content -->
        <footer>
          <div class="pull-right">
            2017 <a href="">2017</a>
          </div>
          <div class="clearfix"></div>
        </footer>
        <!-- /footer content -->
      </div>
    </div>

    <!-- jQuery -->
    <script src="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
vendors/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap -->
    <script src="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
vendors/bootstrap/dist/js/bootstrap.min.js"></script>
    <!-- FastClick -->
    <script src="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
vendors/fastclick/lib/fastclick.js"></script>
    <!-- NProgress -->
    <script src="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
vendors/nprogress/nprogress.js"></script>
    <!-- Chart.js -->
    <script src="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
vendors/Chart.js/dist/Chart.min.js"></script>
    <!-- gauge.js -->
    <script src="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
vendors/gauge.js/dist/gauge.min.js"></script>
    <!-- bootstrap-progressbar -->
    <script src="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
vendors/bootstrap-progressbar/bootstrap-progressbar.min.js"></script>
    <!-- iCheck -->
    <script src="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
vendors/iCheck/icheck.min.js"></script>
    <!-- Skycons -->
    <script src="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
vendors/skycons/skycons.js"></script>
    <!-- Flot -->
    <script src="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
vendors/Flot/jquery.flot.js"></script>
    <script src="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
vendors/Flot/jquery.flot.pie.js"></script>
    <script src="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
vendors/Flot/jquery.flot.time.js"></script>
    <script src="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
vendors/Flot/jquery.flot.stack.js"></script>
    <script src="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
vendors/Flot/jquery.flot.resize.js"></script>
    <!-- Flot plugins -->
    <script src="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
vendors/flot.orderbars/js/jquery.flot.orderBars.js"></script>
    <script src="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
vendors/flot-spline/js/jquery.flot.spline.min.js"></script>
    <script src="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
vendors/flot.curvedlines/curvedLines.js"></script>
    <!-- DateJS -->
    <script src="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
vendors/DateJS/build/date.js"></script>
    <!-- JQVMap -->
    <script src="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
vendors/jqvmap/dist/jquery.vmap.js"></script>
    <script src="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
vendors/jqvmap/dist/maps/jquery.vmap.world.js"></script>
    <script src="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
vendors/jqvmap/examples/js/jquery.vmap.sampledata.js"></script>
    <!-- bootstrap-daterangepicker -->
    <script src="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
vendors/moment/min/moment.min.js"></script>
    <script src="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
vendors/bootstrap-daterangepicker/daterangepicker.js"></script>

    <!-- Custom Theme Scripts -->
    <script src="<?php echo $_smarty_tpl->tpl_vars['BASE_URL']->value;?>
javascript/admin/custom.js"></script>

  </body>
</html><?php }} ?>
